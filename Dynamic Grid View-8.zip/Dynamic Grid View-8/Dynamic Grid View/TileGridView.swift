//
//  TileGridView.swift
//  Dynamic Grid View
//
//  Created by Patil, Ritesh on 4/29/20.
//  Copyright © 2020 Patil, Ritesh. All rights reserved.
//

import SwiftUI
import Combine


 

public struct TileGridView {

    private let viewModel: ViewModel

    public init(viewModel: ViewModel) {

        self.viewModel = viewModel

    }

}
public extension TileGridView {

/// View model for a Tile View
    struct ViewModel {

    public let columns: Int

    public let rows: Int

    public let tileView: [Type]
        
        public var tileViewChunk: [[Type]]

        public init(columns: Int, rows: Int, tileView: [Type], tileViewChunk : [[Type]]) {

        self.columns = columns

        self.rows = rows

        self.tileView = Array(tileView[8...11])
        
        self.tileViewChunk = self.tileView.generateGrid(into: self.tileView.count > 2 ? 2 : 1)

    }

}

}


extension TileGridView: View {
    
 
    
    public var body: some View {

//        self.viewModel.tileViewChunk = self.viewModel.tileView.generateGrid(into: 2)
        
        ScrollView(.horizontal,showsIndicators: true){
       
            
            VStack( spacing: 8) {

                ForEach(0 ..< self.viewModel.tileViewChunk.count) {   i  in
                
                HStack(alignment: .center, spacing: 8) {

                    ForEach(0 ..< self.viewModel.tileViewChunk[i].count) {  j in
                  
                    
                    
                    TileView(data: self.viewModel.tileViewChunk[i][j])
                   

                }

            }

            }

        }.padding(8)
        }

    }
    
    /*
    public var body: some View{
        ScrollView(.horizontal, content: {
            HStack(spacing: 8) {
                ForEach(1...self.viewModel.columns,id:\.self){
                    i in
                    VStack{
                    TileView(data: Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical")).frame(width: UIScreen.main.bounds.size.width / 2 - 16, height: 138)
                    TileView(data: Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical")).frame(width: UIScreen.main.bounds.size.width / 2 - 16, height: 138)
                    
                    
                    }
                    
                }
            }
            .padding(.leading, 8)
        })
            .frame(height: 150)
    }
    */
}



struct TileGridViewPreviews: PreviewProvider {

    static var previews: some View {

        let viewModel = TileGridView.ViewModel(

            columns: 2,

            rows: 2,

            tileView: [
            
                Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),
                Type(iconName: "Filter", planName: "Dental Plan with MetLife", planType: "Dental"),
                Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),
                Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions"),
         
            ],
    tileViewChunk : [[Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),Type(iconName: "Filter", planName: "Dental Plan with MetLife",
                    planType: "Dental") , Type(iconName: "Home", planName: "Theta  test Plan", planType: "Medical")],[Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions")],[Type(iconName: "Home", planName: "Theta  test Plan", planType: "Medical")]]

        )

        return TileGridView(viewModel: viewModel)

    }

}


 

