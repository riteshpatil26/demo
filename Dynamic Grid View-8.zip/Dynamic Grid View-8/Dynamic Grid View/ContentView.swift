//
//  ContentView.swift
//  Dynamic Grid View
//
//  Created by Patil, Ritesh on 4/21/20.
//  Copyright © 2020 Patil, Ritesh. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var data = [Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),
                       Type(iconName: "Filter", planName: "Dental Plan with MetLife", planType: "Dental"),
                       Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),
                       Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions"),Type(iconName: "Home", planName: "Indra  Plan", planType: "Medical"),
                       Type(iconName: "Filter", planName: "Ritesh Plan with MetLife", planType: "Dental"),
                       Type(iconName: "Search", planName: "Mumbai Vision", planType: "Vision"),
                       Type(iconName: "Chat", planName: "USA Caremark ", planType: "Prescriptions"),
                       Type(iconName: "Chat", planName: "USA Caremark", planType: "Prescriptions")
                       
    ]
    
    @State var data2 = [Type(iconName: "Home", planName: "Indra  Plan", planType: "Medical"),
    Type(iconName: "Filter", planName: "Ritesh Plan with MetLife", planType: "Dental"),
    Type(iconName: "Search", planName: "Mumbai Vision", planType: "Vision"),
    Type(iconName: "Chat", planName: "USA Caremark ", planType: "Prescriptions"),
    Type(iconName: "Chat", planName: "USA Caremark", planType: "Prescriptions")]
    
    @State var Grid :[Int] = []
    
    let pageSize = 4
    let pageCount = 3
    
    let viewModel = TileGridView.ViewModel(

        columns: 2,

        rows: 2,

//        tileView: [[Type]] = [[Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),Type(iconName: "Filter", planName: "Dental Plan with MetLife", planType: "Dental")],[ Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),
//                   Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions")]]
        
        tileView: [

            Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),
            Type(iconName: "Filter", planName: "Dental Plan with MetLife", planType: "Dental"),
            Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),
            Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions"),
            Type(iconName: "Home", planName: "Theta Health Plan 1", planType: "Medical"),
            Type(iconName: "Filter", planName: "Dental Plan with MetLife 1", planType: "Dental"),
            Type(iconName: "Search", planName: "Theta Vision 1", planType: "Vision"),
            Type(iconName: "Chat", planName: "CVS Caremark 1", planType: "Prescriptions"),
            Type(iconName: "Home", planName: "Theta Health Plan 2", planType: "Medical"),
            Type(iconName: "Filter", planName: "Dental Plan with MetLife 2", planType: "Dental"),
            Type(iconName: "Search", planName: "Theta Vision 2", planType: "Vision"),
            Type(iconName: "Chat", planName: "CVS Caremark 2", planType: "Prescriptions")
            

        ],
        
        tileViewChunk:  []

    )
    
    
    
    var body: some View {
        
        
        
        VStack(alignment: .leading,spacing: 0){
            ZStack(alignment: .center){
                Text("$323.32").font(.title).fontWeight(.bold)
            }
            Spacer(minLength: 10)
            Text("Enrolled Plans").padding(.leading, 8)
//            HStack{
//
//            }
           //
            
            ScrollView(.horizontal, content: {
                HStack(spacing: 0) {
//                    ForEach(1...data.count / 4,id:\.self){
//                        i in
                    
                    TileGridView(viewModel: viewModel)
//                    MainView(data: self.$data, Grid: self.$Grid).frame(width:UIScreen.main.bounds.width , height: 308, alignment:.top)
                       
                        
//                    }
                }
                .padding(.leading, 0)
            })
           
           
            Spacer()
//            RecommendedView()
          
            Spacer()
        
        }.background(Color.yellow.opacity(0.8).edgesIgnoringSafeArea(.top))
            .edgesIgnoringSafeArea(.bottom)
            .onAppear {
                self.generateGrid()
        }
    }
    
    
    func generateGrid(){
        for i in stride(from: 0, to: self.data.count, by: 2){
            if i != self.data.count{
                self.Grid.append(i)
            }
            
        }
    }
 
    
}
extension Array {
    func generateGrid(into size: Int) -> [[Element]] {
        return stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
   
    
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

public struct TileView :View {
   var data :Type
//   var data1 :Type
    public var body: some View {
        
            VStack(alignment: .leading,spacing: 0) {
                HStack {
                    Spacer()
                    Image("Home").resizable().frame(width: 28, height: 28).aspectRatio(contentMode: .fit)
                }
                Spacer()
                HStack {
                    Text(data.planName).lineLimit(2)
                }
                Spacer()
                HStack {
                    Text(data.planType)
                }.padding([.bottom], 4)
                }

        .padding(8)
        .background(Color.red.opacity(0.4))
        .cornerRadius(14)
            .lineLimit(1).frame(height: 138.0)
    }
}







struct MainView :View{
    @Binding var data :[Type]
    @Binding var Grid :[Int]
    
    
    
    var body: some View{
      
    
        HStack{
        
            
            if !self.Grid.isEmpty{
                            
                
                ScrollView(.horizontal,showsIndicators: false){
                    HStack(spacing: 8){
                    
                    ForEach(self.Grid,id: \.self){
                        i in
                        VStack(alignment : .leading,spacing: 8){
                            ForEach(i...i+1,id: \.self){ j in
                          
                                    HStack{
                                    if j != self.data.count{
//                                        TileView(data:self.data[j] )
                                        
                                        TileView(data:self.data[j]).frame(width: (UIScreen.main.bounds.size.width / 2) - 16, height: 138.0)
                                        
                                    }
                                    }
                                    
                            }
                          
                            if i == self.Grid.last && self.data.count % 2 != 0 {
                                
//                                Spacer(minLength: 0)
                            }
                            
                        }
                        
                    }
                    }.padding()
            }
        }
            
        }
        
        
    }
    

    
}


public struct Type{
    public var iconName: String
    public var planName: String
    public var planType: String
    private let uuid = UUID()
    
    public init(iconName: String, planName: String, planType: String) {
        self.iconName = iconName
        self.planName = planName
        self.planType = planType
    }
    
    }

